package com.fins.fins_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
